# NoSQL Database Design – Lab Sheet 3

COER University — MongoDB / NoSQL Lab Sheet 3

This repository contains solutions for all 15 problems from the uploaded Lab Sheet 3.

## Requirements
- MongoDB Server or MongoDB Atlas
- `mongosh` (MongoDB Shell)

## How to run
Open a project folder and run:

```bash
mongosh
load("solution.js")
```

Or paste the contents of `solution.js` into MongoDB Compass/Mongosh.

## Topics covered
1. Student Activity Tracking
2. Event Logging
3. Mini Blogging Platform
4. Flexible Product Catalog
5. E-Commerce Order Management
6. Website Analytics
7. Content Management System
8. Shopping Cart with Embedded Documents
9. Product Review and Rating
10. Inventory Monitoring
11. Bank Wallet Transfer using Transactions
12. User Notification System
13. Course Learning Platform
14. Real-Time Order Tracking
15. Flexible News Database

## Note
Problem 11 uses MongoDB transactions. Transactions require MongoDB Atlas or a MongoDB deployment configured as a replica set.
