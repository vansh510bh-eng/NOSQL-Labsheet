# 04 Flexible Product Catalog

Run `solution.js` in MongoDB Shell (`mongosh`).
