# 11 Bank Wallet Transfer

Run `solution.js` in MongoDB Shell (`mongosh`).
