# 13 Course Learning Platform

Run `solution.js` in MongoDB Shell (`mongosh`).
