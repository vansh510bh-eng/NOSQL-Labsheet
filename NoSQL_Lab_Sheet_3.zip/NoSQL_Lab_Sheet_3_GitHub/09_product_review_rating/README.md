# 09 Product Review Rating

Run `solution.js` in MongoDB Shell (`mongosh`).
