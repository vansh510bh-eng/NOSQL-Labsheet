# 08 Shopping Cart

Run `solution.js` in MongoDB Shell (`mongosh`).
