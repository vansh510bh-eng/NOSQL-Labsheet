# 12 User Notification System

Run `solution.js` in MongoDB Shell (`mongosh`).
