# 14 Real Time Order Tracking

Run `solution.js` in MongoDB Shell (`mongosh`).
