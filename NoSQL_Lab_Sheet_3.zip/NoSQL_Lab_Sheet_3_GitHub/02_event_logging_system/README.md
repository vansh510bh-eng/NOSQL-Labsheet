# 02 Event Logging System

Run `solution.js` in MongoDB Shell (`mongosh`).
