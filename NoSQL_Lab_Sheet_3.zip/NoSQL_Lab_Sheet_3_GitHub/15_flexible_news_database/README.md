# 15 Flexible News Database

Run `solution.js` in MongoDB Shell (`mongosh`).
