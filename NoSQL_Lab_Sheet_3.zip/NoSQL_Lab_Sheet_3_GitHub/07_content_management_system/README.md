# 07 Content Management System

Run `solution.js` in MongoDB Shell (`mongosh`).
