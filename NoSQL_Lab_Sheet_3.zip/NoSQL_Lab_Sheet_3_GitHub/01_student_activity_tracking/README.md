# 01 Student Activity Tracking

Run `solution.js` in MongoDB Shell (`mongosh`).
