# 10 Inventory Monitoring

Run `solution.js` in MongoDB Shell (`mongosh`).
