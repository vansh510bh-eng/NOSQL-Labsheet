# 03 Mini Blogging Platform

Run `solution.js` in MongoDB Shell (`mongosh`).
