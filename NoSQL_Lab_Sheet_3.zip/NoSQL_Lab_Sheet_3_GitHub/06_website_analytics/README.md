# 06 Website Analytics

Run `solution.js` in MongoDB Shell (`mongosh`).
