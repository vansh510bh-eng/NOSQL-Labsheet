# NoSQL Database Design – Lab Sheet 4

Code solutions for all 15 questions in the supplied lab sheet, arranged by database and question number.

## Contents
- `HBase/Q01_Student.hbase` through `HBase/Q10_Regions.hbase`: HBase shell commands for questions 1–10.
- `Cassandra/Q11_CollegeDB.cql` through `Cassandra/Q14_Consistency.cql`: CQL for questions 11–14.
- `Project_Q15/`: A small HBase Content Management System example for question 15, including CRUD commands and a short explanation.

## How to run
1. Install and start Apache HBase or Apache Cassandra using the official documentation for your operating system/distribution.
2. For `.hbase` files, open the HBase shell with `hbase shell`, then paste/run the commands in the file. These files are shell command scripts, not standalone Java programs.
3. For `.cql` files, connect with `cqlsh` and run the commands. `CONSISTENCY` is a `cqlsh` client command, not a CQL statement sent to the server.
4. Run each question independently where possible. Some scripts create tables with fixed names; rerunning them may require dropping the table first.

## Notes
- HBase table and column-family names are case-sensitive in practice; use the names shown in each script consistently.
- HBase TTL is configured in seconds. Expiration is asynchronous and may not be immediately visible until cleanup/compaction; use `TTL => 5` only for demonstration.
- Cassandra event queries use a composite primary key so a user's events can be queried by time. Cassandra is query-driven: choose partition keys to match required queries.
- The multi-region HBase example uses pre-split keys and may require a running multi-node cluster to observe distribution across RegionServers. A single-node setup can still demonstrate region boundaries, but not meaningful multi-server distribution.
- Replace example names, emails, and IDs with your own test data if required by your instructor.
