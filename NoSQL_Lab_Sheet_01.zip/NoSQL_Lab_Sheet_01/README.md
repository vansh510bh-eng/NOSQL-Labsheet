# NoSQL Database Design - Lab Sheet 01

## Subject
NoSQL Database Design

## Database
MongoDB

## Lab
Lab Sheet-01

## Topics Covered
- Database and collection management
- Document insertion
- Read/find operations
- Projection
- updateOne()
- updateMany()
- replaceOne()
- $set and $unset
- deleteOne()
- deleteMany()
- countDocuments()
- Collection rename
- Collection drop
- Database drop and recreation
- MongoDB Compass
- MongoDB Shell
- MongoDB vs SQL CRUD comparison

## Files

- `lab01.mongodb.js` - MongoDB commands for Q1-Q25
- `Lab_Sheet_1.pdf` - Original lab sheet
- `screenshots/` - Add your practical output screenshots here

## How to Run

1. Install MongoDB Community Edition and MongoDB Shell (mongosh).
2. Open `mongosh`.
3. Open/copy the commands from `lab01.mongodb.js`.
4. Execute the practicals in order.
5. Take screenshots of important outputs.
6. Add screenshots to the `screenshots` folder.
7. Push the folder to GitHub.

## Important Warning

Q20 drops the `StudentDB` database. Execute it only after completing the earlier practicals. Q21 recreates the database.

## GitHub Note

Do not upload `node_modules`, MongoDB server installation files, or unnecessary local system files.
