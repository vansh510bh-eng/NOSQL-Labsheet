Add your MongoDB Shell and MongoDB Compass output screenshots in this folder.
