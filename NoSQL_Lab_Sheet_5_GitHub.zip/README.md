# NoSQL Database Design — Lab Sheet 5

This repository contains example code for all 15 questions in the supplied lab sheet:
- **Questions 1–10:** Riak KV examples using its HTTP API (legacy Riak KV installations commonly expose port `8098`).
- **Questions 11–15:** Neo4j Cypher scripts and a small Python CRUD application.

## Requirements
- Python 3.10+
- `pip install -r requirements.txt`
- A running Riak KV node for Q1–Q10 (set `RIAK_URL`, default `http://localhost:8098`)
- Neo4j Desktop/Server for Q11–Q14 (run scripts in Neo4j Browser)
- Neo4j Python driver for Q15 (set `NEO4J_URI`, `NEO4J_USER`, and `NEO4J_PASSWORD`)

> **Compatibility note:** Riak KV versions and installations differ. These examples use the classic HTTP API and are educational templates; confirm your server's API, bucket-type configuration, and supported query/index features before running. Riak KV does not provide general multi-record ACID transactions. Neo4j scripts use Cypher syntax suitable for modern Neo4j versions; Q14 demonstrates a transaction block in the application example, because transaction syntax depends on the client.

## Run Python examples
```bash
pip install -r requirements.txt
python q01_riak_student_crud.py
```
Most Riak examples call the running Riak HTTP endpoint. Neo4j scripts (`.cypher`) can be copied into Neo4j Browser and executed.

## File map
- `q01`–`q10`: Riak KV exercises
- `q11`–`q14`: Neo4j Cypher exercises
- `q15_neo4j_crud_app.py`: Neo4j CRUD example
