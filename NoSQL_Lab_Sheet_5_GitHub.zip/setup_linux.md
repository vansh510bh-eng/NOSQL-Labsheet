# Setup notes (Linux)

## Riak KV (Q1–Q10)
Riak KV is a legacy product and installation instructions vary by Linux distribution and version. Use the package/container recommended for your course environment and verify that the HTTP API is enabled and reachable at `http://localhost:8098`. These scripts use the classic Riak HTTP API.

Check connectivity:
```bash
curl -i http://localhost:8098/
```
Set a custom endpoint if needed:
```bash
export RIAK_URL=http://localhost:8098
```

## Neo4j (Q11–Q15)
1. Install Neo4j Desktop or Neo4j Server and start a local database.
2. Open Neo4j Browser and run the `.cypher` files for Q11–Q14.
3. Install Python dependencies: `python -m pip install -r requirements.txt`
4. Set connection environment variables before Q15:
```bash
export NEO4J_URI=bolt://localhost:7687
export NEO4J_USER=neo4j
export NEO4J_PASSWORD='your_database_password'
python q15_neo4j_crud_app.py
```

Do not commit real passwords or `.env` files to GitHub. The examples use sample data only.
