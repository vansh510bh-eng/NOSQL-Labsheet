# NoSQL Database Design - Lab Sheet 2

This repository contains code for all 15 experiments from the uploaded lab sheet.

## Experiments

1. RDBMS and MongoDB student database comparison
2. MongoDB CollegeDB Students CRUD
3. MongoDB Orders with embedded products and aggregation
4. Redis student information system
5. Cassandra CollegeDB Students
6. HBase Students table
7. Neo4j Student-Course graph
8. MongoDB vs Cassandra vs Neo4j comparison
9. Single-server MongoDB CRUD
10. MongoDB sharding
11. MongoDB primary-secondary replication
12. Cassandra peer-to-peer replication
13. Sharding + replication architecture
14. MapReduce on student data
15. Database distribution models

## Suggested GitHub Structure

Each experiment has its own numbered folder. Code is provided in the native format for the database:
- `.sql` for MySQL
- `.js` for MongoDB shell
- `.redis` for Redis commands
- `.cql` for Cassandra
- `.hbase` for HBase shell
- `.cypher` for Neo4j
- `.md` for explanations/configuration

## Important

Experiments involving clusters (MongoDB sharding/replication and Cassandra multi-node replication) require the corresponding database cluster environment. The files contain the commands/configuration needed for the demonstration.
