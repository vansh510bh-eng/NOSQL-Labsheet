# Comparison

| Feature | MongoDB | Cassandra | Neo4j |
|---|---|---|---|
| Data model | Document | Wide-column | Graph |
| Storage | BSON documents | Rows in partitions/columns | Nodes and relationships |
| Query method | MongoDB Query Language | CQL | Cypher |
| Scalability | Horizontal scaling | Excellent horizontal scaling | Scales graph workloads with architecture considerations |
| Suitable applications | Content, catalogs, flexible records | Large distributed datasets, high write workloads | Social networks, recommendations, connected data |
