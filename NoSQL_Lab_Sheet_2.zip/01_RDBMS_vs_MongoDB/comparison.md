# RDBMS vs NoSQL Document Model

| Feature | MySQL RDBMS | MongoDB |
|---|---|---|
| Schema | Fixed table schema | Flexible document schema |
| Storage | Rows and columns | BSON/JSON-like documents |
| Flexibility | Lower | Higher |
| Relationships | Foreign keys / joins | Embedded documents or references |
| Scalability | Mainly vertical, supports clustering | Designed for horizontal scaling |
| Suitable for | Structured transactional data | Flexible and rapidly changing data |
